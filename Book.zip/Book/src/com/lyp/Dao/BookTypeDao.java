package com.lyp.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class BookTypeDao {
	
	//ͼ����������
	public boolean select(Connection con , String type) throws Exception{
		
		String sql = "insert into booktype(type) values(?)";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setString(1, type);
		int count = pstmt.executeUpdate();
		if(count > 0){
			return true;
		}else{
			return false;
		}
		
	}
	
	
	//ͼ�����Ͳ�ѯ
	public boolean select(Connection con , int id) throws Exception{
		String sql = "select * from booktype where id = ?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, id);
		ResultSet rs = pstmt.executeQuery();
		if(rs.next()){
			return true;
		}else{
			return false;
		}
	}
	public int queryIdByType(Connection con , String type) throws Exception{
		String sql = "select * from booktype where type = ?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setString(1, type);
		ResultSet rs = pstmt.executeQuery();
		int result = 0;
		if(rs.next()){
			result = rs.getInt("id");
			return result;
		}else{
			return result;
		}
	}
	//ͼ������ɾ��
	public boolean delete(Connection con ,String type)throws Exception{
		String sql = "delete * from booktype where type = ?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setString(1, type);
		int count= pstmt.executeUpdate();
		if(count > 0){
			return true;
		}else{
			return false;
		}
	}
}
