package com.lyp.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.lyp.bean.ReaderBean;
import com.lyp.bean.WorkerBean;


public class ReaderDao {
	
	//���Ӷ�����Ϣ
	public int insert(Connection con, ReaderBean reader) throws Exception {

		String sql = "insert into Reader(borrow_id , reader_name , sex , college , type , certificate_type , certificate_id , phone , certificate_date , borrow_book_num ,max_book_num , yuqi_state) values(?,?,?,?,?,?,?,?,?,?,?,?)";
		PreparedStatement pstmt = con.prepareStatement(sql);

		pstmt.setInt(1, reader.getBorrow_id());
		pstmt.setString(2, reader.getReader_name());
		pstmt.setString(3, reader.getSex());
		pstmt.setString(4, reader.getCollege());
		pstmt.setString(5, reader.getType());
		pstmt.setString(6, reader.getCertificate_type());
		pstmt.setString(7, reader.getCertificate_id());
		pstmt.setString(8, reader.getPhone());
		pstmt.setString(9, reader.getCertificate_date());
		pstmt.setInt(10, reader.getBorrow_book_num());
		pstmt.setInt(11, reader.getMax_book_num());
		pstmt.setString(12, reader.getYuqi_state());
		
		return pstmt.executeUpdate();

	}

	// ע��  ����id����֤��ɾ������
	public boolean delete(Connection con, int id) throws Exception {

		String sql = "delete from Reader where borrow_id = ?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, id);
		if(pstmt.executeUpdate() > 0){
			return true;
		}else{
			return false;
		}
	}
	//�޸�֤����
	public boolean update(Connection con, int id, String certificate_id) throws Exception {

		String sql = "update reader set certificate_id = ? where borrow_id = ?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setString(1, certificate_id);
		pstmt.setInt(2, id);
		if(pstmt.executeUpdate() > 0){
			return true;
		}else{
			return false;
		}
	}
	
	//��ѧ�Ų�ѯ
	public boolean queryById(Connection con, int id) throws Exception {

		String sql = "select * from reader where borrow_id = ?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, id);
		ResultSet rs = pstmt.executeQuery();
		if(rs.next()){
			return true;
		}
		else{
			return false;
		}
	}
	
	//��ʾ���ж�����Ϣ
	
	public List query(Connection con) throws Exception {

		List<ReaderBean> readerlist = new ArrayList<ReaderBean>();
		ResultSet rs = null;
		String sql = "select * from reader";
		PreparedStatement pstmt = con.prepareStatement(sql);
		rs = pstmt.executeQuery();
		while(rs.next()){
			ReaderBean reader = new ReaderBean();
			reader.setBorrow_id(rs.getInt("borrow_id"));
			reader.setReader_name(rs.getString("reader_name"));
			reader.setSex(rs.getString("sex"));
			reader.setCollege(rs.getString("college"));
			reader.setType(rs.getString("type"));
			reader.setCertificate_type(rs.getString("certificate_type"));
			reader.setCertificate_id(rs.getString("certificate_id"));
			reader.setPhone(rs.getString("phone"));
			reader.setCertificate_date(rs.getString("certificate_date"));
			reader.setMax_book_num(rs.getInt("max_book_num"));
			readerlist.add(reader);
		}
		
		return readerlist ;
	}

	public String queryReaderNameById(Connection con, int reader_id) throws SQLException {
		
		String count = null;
		ResultSet rs = null;
		String sql = "select * from reader where borrow_id = ?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, reader_id);
		rs = pstmt.executeQuery();
		if(rs.next()){
			count = rs.getString("reader_name");
			return count;
		}else{
			return null;
		}
		
	}
	
	//����������Ϊ�����ڶ���
	public boolean updateyuqi (Connection con , int reader_id) throws SQLException{
		String sql = "update reader set yuqi_state = '������' where borrow_id = ?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		if(pstmt.executeUpdate() > 0){
			return true;
		}else{
			return false;
		}
	}
	//���߽�������� 1
	public boolean addcangshu (Connection con , int reader_id) throws SQLException{
		String sql = "update reader set borrow_book_num = borrow_book_num + 1 where borrow_id = ?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, reader_id);
		if(pstmt.executeUpdate() > 0){
			return true;
		}else{
			return false;
		}
	}
	//���߻������������ 1
		public boolean poorcangshu (Connection con , int reader_id) throws SQLException{
			String sql = "update reader set borrow_book_num = borrow_book_num - 1 where borrow_id = ?";
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, reader_id);
			if(pstmt.executeUpdate() > 0){
				return true;
			}else{
				return false;
			}
		}
}