package com.lyp.Dao;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import com.lyp.bean.jieyueBean;

public class JieyueDao {
	
	//���ӽ��ļ�¼
	public int insert(Connection con , jieyueBean jieyuebean) throws SQLException{
		String sql = "insert into jieyue(book_id , borrow_id ,reader_name , book_name , borrow_date , yinghuan_date , return_date) values(?,?,?,?,?,?,?)";
		PreparedStatement pstmt = con.prepareStatement(sql);
		
		pstmt.setInt(1, jieyuebean.getBook_id());
		pstmt.setInt(2, jieyuebean.getBorrow_id());
		pstmt.setString(3, jieyuebean.getReader_name());
		pstmt.setString(4, jieyuebean.getBook_name());
		pstmt.setString(5,jieyuebean.getBorrow_date());
		pstmt.setString(6,jieyuebean.getYinghuan_date());
		pstmt.setString(7,jieyuebean.getReturn_date());
		return pstmt.executeUpdate();
	}
	//����ʵ�ʹ黹����
	public void update(Connection con , String redate, int book_id , int reader_id ) throws SQLException, ParseException{
		String sql = "update jieyue set return_date = ? where book_id = ? and borrow_id = ?";
		
		PreparedStatement pstmt = con.prepareStatement(sql);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date returndate = sdf.parse(redate);
		java.sql.Date sqlDate = new java.sql.Date(returndate.getTime());
		pstmt.setDate(1,sqlDate);
		pstmt.setInt(2, book_id);
		pstmt.setInt(3, reader_id);
		pstmt.executeUpdate();
	}
	
	
	
	//��ѯ��Ӧ������
	public String queryDateByBookId (Connection con , int book_id , int reader_id) throws SQLException{
		ResultSet rs = null;
		String sql = "select yinghuan_date from jieyue where book_id = ? and borrow_id = ?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, book_id);
		pstmt.setInt(2, reader_id);
		rs = pstmt.executeQuery();
		
		if(rs.next()){
			Date yinghuan_date = rs.getDate("yinghuan_date");
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	        String format = sdf.format(yinghuan_date);       //��Date����ת����String����   
			return format;
		}else{
			return null;
		}
		
		
	}
	
	
	//���н��ļ�¼
	public List queryAll(Connection con ) throws SQLException{
		List<jieyueBean> list = new ArrayList<jieyueBean>();
		String sql = "select * from jieyue";
		PreparedStatement pstmt = con.prepareStatement(sql);
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()){
			jieyueBean  jy = new jieyueBean();
			jy.setReader_name(rs.getString("reader_name"));
			jy.setBook_name(rs.getString("book_name"));
			jy.setBorrow_date(rs.getString("borrow_date"));
			jy.setYinghuan_date(rs.getString("yinghuan_date"));
			list.add(jy);
		}
		return list;
	}
	
}
