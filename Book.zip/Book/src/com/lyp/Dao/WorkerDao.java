package com.lyp.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.lyp.bean.ReaderBean;
import com.lyp.bean.WorkerBean;



public class WorkerDao {
		//����ְ��
		public int insert(Connection con,WorkerBean worker)throws Exception{
		
			String sql = "insert into Worker(id,name,sex,phone,password) values(?,?,?,?,?)";
			PreparedStatement pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1, worker.getId());
			pstmt.setString(2, worker.getName());
			pstmt.setInt(3, worker.getSex());
			pstmt.setString(4, worker.getPhone());
			pstmt.setString(5, worker.getPassword());
		
		return pstmt.executeUpdate();
		
		}
		
		//ɾ��
		public int delete(Connection con , int id)throws Exception{
			String sql = "delete from Worker where id=?";
			
			PreparedStatement pstmt = con.prepareStatement(sql);//Ԥ����
			pstmt.setInt(1, id);
			
			return pstmt.executeUpdate();
		}
		
		//�޸�
		public int update(Connection con , int id, String Pwd)throws Exception{
			String sql = "update worker set password = ? where id=?";
			
			PreparedStatement pstmt = con.prepareStatement(sql);//Ԥ����
			pstmt.setString(1, Pwd);
			pstmt.setInt(2, id);
			
			return pstmt.executeUpdate();
		}
		
		//��ѯ
		public ResultSet queryById(Connection con , int id)throws Exception{
			String sql = "select * from worker where id=?";
			
			PreparedStatement pstmt = con.prepareStatement(sql);//Ԥ����
			
			pstmt.setInt(1, id);
			ResultSet rs = pstmt.executeQuery();
			return rs;
		}
		//��ʾ����ְ���б� ----- 
		public List query(Connection con) throws Exception {
			List<WorkerBean> list = new ArrayList<WorkerBean>();
			String sql = "select * from worker";
			PreparedStatement pstmt = con.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();
			ResultSet rset = rs;
			System.out.println(122121);
			while(rs.next()){
				WorkerBean worker = new WorkerBean();
				worker.setId(rs.getInt("id"));
				worker.setName(rs.getString("name"));
				worker.setSex(rs.getInt("sex"));
				worker.setPhone(rs.getString("phone"));
				worker.setPassword(rs.getString("password"));
				list.add(worker);
			}
			return list;
		}
		/*
		public List query(Connection con) throws Exception {

			List<ReaderBean> readerlist = new ArrayList<ReaderBean>();
			ResultSet rs = null;
			String sql = "select * from reader";
			PreparedStatement pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while(rs.next()){
				ReaderBean reader = new ReaderBean();
				reader.setBorrow_id(rs.getInt("borrow_id"));
				reader.setReader_name(rs.getString("reader_name"));
				reader.setSex(rs.getString("sex"));
				reader.setCollege(rs.getString("college"));
				reader.setType(rs.getString("type"));
				reader.setCertificate_type(rs.getString("certificate_type"));
				reader.setCertificate_id(rs.getString("certificate_id"));
				reader.setPhone(rs.getString("phone"));
				reader.setCertificate_date(rs.getString("certificate_date"));
				reader.setMax_book_num(rs.getInt("max_book_num"));
				readerlist.add(reader);
			}
			
			return readerlist ;
		}*/
}
