package com.lyp.Dao;

import com.lyp.bean.BookBean;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class BookDao {
	
	//ͼ������
	public int insert(Connection con , BookBean bookbean)throws Exception{
		String sql = "insert into book(book_id, book_name , book_type , editor , publishing_house , price, book_num , shujia_id, ruku_date) values(?,?,?,?,?,?,?,?,?)"; 
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setInt(1 , bookbean.getBook_id());
		pstmt.setString(2, bookbean.getBook_name());
		pstmt.setInt(3, bookbean.getBook_type());
		pstmt.setString(4, bookbean.getEditor());
		pstmt.setString(5 , bookbean.getPublishing_house());
		pstmt.setString(6, bookbean.getPrice());
		pstmt.setInt(7, bookbean.getBook_num());
		pstmt.setInt(8, bookbean.getShujia_id());
		pstmt.setString(9, bookbean.getRuku_date());
		return pstmt.executeUpdate();
	}
	
	
	//ͼ��ɾ��
	public boolean delete(Connection con , int id)throws Exception{
		
		int count = 0;
		String sql = "delete from Book where book_id = ?"; 
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setInt(1,id);
		count = pstmt.executeUpdate();
		if(count>0){
			return true;
		}else{
			return false;
		}
	}
	//ͼ�������޸�,�����д�
	public boolean update(Connection con , int id , String book_type)throws Exception{
		int book_type_id = queryType(con,book_type);
		if(book_type_id > 0){//�ҵ��������͵���������,��ʼ�޸�
			String sql = "update book set book_type = ? where book_id= ?";  //////
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, book_type_id);
			pstmt.setInt(2, id);
			int count = pstmt.executeUpdate();
			if(count > 0 ){
				System.out.println("�޸�һ����ɹ�!!!");
				return true;
			}else{
				System.out.println("û���޸ĳɹ���������Ӧ�ò������!!!");
				return false;
			}
		}else{
			System.out.println("��û�ҵ� ��û���޸�!!!");
			return false;
		}
	}
	//����һ���Ѿ����ڵ��飬��������1
	public boolean updatebooknum(Connection con , int id)throws Exception{
		int count = 0;
		ResultSet rs = null;
		String sql = "update book set book_num=book_num+1 where book_id = ?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, id);
		count = pstmt.executeUpdate();
		if(count > 0){
			return true;
		}else{
			return false;
		}
	}
	//ͼ���ѯ  ��������Ų�ѯͼ��
	public boolean queryById(Connection con , int id)throws Exception{
		int count = 0;
		ResultSet rs = null;
		String sql = "select * from Book where book_id = ?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, id);
		rs = pstmt.executeQuery();
		if(rs.next()){
			return true;
		}else{
			return false;
		}
	}
	//ͼ���ѯ������ͼ�����Ͳ�ѯͼ��
	public boolean queryByType(Connection con , String book_type)throws Exception{
		int count = 0;
		ResultSet rs = null;
		String sql = "select * from Book where book_type = ?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setString(1, book_type);
		rs = pstmt.executeQuery();
		if(rs.next()){
			return true;
		}else{
			return false;
		}
	}
	//����������Ͳ�ѯ������ID,   ����   id
	public int queryType(Connection con , String book_type)throws Exception{
		int count = 0;
		ResultSet rs = null;
		String sql = "select * from booktype where type = ?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setString(1, book_type);
		rs = pstmt.executeQuery();
		if(rs.next()){
			count = rs.getInt("id");
			return count;
		}else{
			return count;
		}
	}
	//��������id��ѯ����
	public String queryType(Connection con , int id)throws Exception{
		String count = null;
		ResultSet rs = null;
		String sql = "select type from booktype where id = ?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, id);
		rs = pstmt.executeQuery();
		if(rs.next()){
			count = rs.getString("type");
			return count;
		}else{
			return count;
		}
	}
	//���Ҳ������
	public int queryBooknum(Connection con , int book_id)throws Exception{
		int count = 0;
		ResultSet rs = null;
		String sql = "select book_num from book where book_id = ?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, book_id);
		rs = pstmt.executeQuery();
		if(rs.next()){
			count = rs.getInt("book_num");
			return count;
		}else{
			return count;
		}
	}
	
	//��ѯ����ͼ��
	public List<BookBean> query(Connection con )throws Exception{
		ResultSet rs = null;
		String sql = "select * from Book ";
		PreparedStatement pstmt = con.prepareStatement(sql);
		rs = pstmt.executeQuery();
		List<BookBean> list = new ArrayList<BookBean>();
		while(rs.next()){
			BookBean book = new BookBean();
			book.setBook_id(rs.getInt("book_id"));
			book.setBook_name(rs.getString("book_name"));
			//book.setBook_type(queryType(con , rs.getInt("book_type")));
			book.setEditor(rs.getString("editor"));
			book.setPublishing_house(rs.getString("publishing_house"));
			book.setPrice(rs.getString("price"));
			book.setBook_num(rs.getInt("book_num"));
			book.setShujia_id(rs.getInt("shujia_id"));
			list.add(book);
		}
		return list;
	}
	//����book_id ��ѯ����
	public String queryBookNameById(Connection con , int book_id)throws SQLException{
		String count = null;
		ResultSet rs = null;
		String sql = "select * from Book where book_id = ?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, book_id);
		rs = pstmt.executeQuery();
		if(rs.next()){
			count = rs.getString("book_name");
			return count;
		}else{
			return null;
		}
	}
	
	//����ɹ������ǲ�����Ҫ -1
	public boolean cangshunumpoor(Connection con , int book_id) throws SQLException{
		String sql = "update book set book_num = book_num - 1 where book_id = ?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, book_id);
		if(pstmt.executeUpdate() > 0){
			return true;
		}else{
			return false;
		}
	}
	//����ɹ�,Ȼ���������1
	public boolean cangshunumadd(Connection con , int book_id) throws SQLException{
		String sql = "update book set book_num = book_num + 1 where book_id = ?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, book_id);
		if(pstmt.executeUpdate() > 0){
			return true;
		}else{
			return false;
		}
	}
}
