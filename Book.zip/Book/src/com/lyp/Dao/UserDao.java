package com.lyp.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UserDao {
	
	public boolean select (Connection con , String username,String pwd) throws SQLException{
		String sql = "select * from administrator where username=? and password=?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setString(1, username);
		pstmt.setString(2, pwd);
		ResultSet rs = pstmt.executeQuery();
		if(rs.next()){
			return true;
		}else{
			return false;
		}
	}
	
	public boolean update (Connection con , String username , String pwd) throws SQLException{
		String sql = "update administrator set password=? where username=?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setString(1, pwd);
		pstmt.setString(2, username);
		int result = pstmt.executeUpdate();
		if(result>0){
			return true;
		}else{
			return false;
		}
	}
}
