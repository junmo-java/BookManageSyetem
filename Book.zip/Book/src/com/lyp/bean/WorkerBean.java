package com.lyp.bean;

public class WorkerBean {
	private int id;
	private String name;
	private int sex;
	private String phone;
	private String password;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getSex() {
		return sex;
	}
	public void setSex(int sex) {
		this.sex = sex;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
	
	public WorkerBean() {
		super();
		
	}
	
	public WorkerBean( String name, int sex, String phone, String password) {
		super();
		this.name = name;
		this.sex = sex;
		this.phone = phone;
		this.password = password;
	}
	
	public WorkerBean(int id, String name, int sex, String phone, String password) {
		super();
		this.id = id;
		this.name = name;
		this.sex = sex;
		this.phone = phone;
		this.password = password;
	}
	
	
	
	
}
