package com.lyp.bean;

import java.sql.Date;

public class BookBean {
	private int book_id;
	private String book_name;
	private int book_type;
	private String editor;
	private String publishing_house;
	private String price;
	private int book_num;
	private int shujia_id;
	private String ruku_date;
	public int getBook_id() {
		return book_id;
	}
	public void setBook_id(int book_id) {
		this.book_id = book_id;
	}
	public String getBook_name() {
		return book_name;
	}
	public void setBook_name(String book_name) {
		this.book_name = book_name;
	}
	public int getBook_type() {
		return book_type;
	}
	public void setBook_type(int book_type) {
		this.book_type = book_type;
	}
	public String getEditor() {
		return editor;
	}
	public void setEditor(String editor) {
		this.editor = editor;
	}
	public String getPublishing_house() {
		return publishing_house;
	}
	public void setPublishing_house(String publishing_house) {
		this.publishing_house = publishing_house;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	public int getBook_num() {
		return book_num;
	}
	public void setBook_num(int book_num) {
		this.book_num = book_num;
	}
	public int getShujia_id() {
		return shujia_id;
	}
	public void setShujia_id(int shujia_id) {
		this.shujia_id = shujia_id;
	}
	public String getRuku_date() {
		return ruku_date;
	}
	public void setRuku_date(String ruku_date) {
		this.ruku_date = ruku_date;
	}
	
	
	
	public BookBean() {
		super();
	}
	public BookBean(int book_id, String book_name, int book_type, String editor, String publishing_house, String price,
			int book_num, int shujia_id, String ruku_date) {
		super();
		this.book_id = book_id;
		this.book_name = book_name;
		this.book_type = book_type;
		this.editor = editor;
		this.publishing_house = publishing_house;
		this.price = price;
		this.book_num = book_num;
		this.shujia_id = shujia_id;
		this.ruku_date = ruku_date;
	}
	
	
	
	
}
