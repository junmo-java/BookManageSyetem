package com.lyp.bean;

import java.sql.Date;

public class ReaderBean {
	private int borrow_id;
	private String reader_name;
	private String sex;
	private String college;
	private String type;
	private String certificate_type;
	private String certificate_id;
	private String phone;
	private String certificate_date;
	private int borrow_book_num;
	private int max_book_num;
	private String yuqi_state;
	public int getBorrow_id() {
		return borrow_id;
	}
	public void setBorrow_id(int borrow_id) {
		this.borrow_id = borrow_id;
	}
	public String getReader_name() {
		return reader_name;
	}
	public void setReader_name(String reader_name) {
		this.reader_name = reader_name;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getCollege() {
		return college;
	}
	public void setCollege(String college) {
		this.college = college;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getCertificate_type() {
		return certificate_type;
	}
	public void setCertificate_type(String certificate_type) {
		this.certificate_type = certificate_type;
	}
	public String getCertificate_id() {
		return certificate_id;
	}
	public void setCertificate_id(String certificate_id) {
		this.certificate_id = certificate_id;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getCertificate_date() {
		return certificate_date;
	}
	public void setCertificate_date(String certificate_date) {
		this.certificate_date = certificate_date;
	}
	public int getBorrow_book_num() {
		return borrow_book_num;
	}
	public void setBorrow_book_num(int borrow_book_num) {
		this.borrow_book_num = borrow_book_num;
	}
	public int getMax_book_num() {
		return max_book_num;
	}
	public void setMax_book_num(int max_book_num) {
		this.max_book_num = max_book_num;
	}
	public String getYuqi_state() {
		return yuqi_state;
	}
	public void setYuqi_state(String yuqi_state) {
		this.yuqi_state = yuqi_state;
	}
	
	
	
	public ReaderBean() {
		super();
	}
	
	public ReaderBean(int borrow_id, String reader_name, String sex, String college, String type,
			String certificate_type, String certificate_id, String phone, String certificate_date, int max_book_num) {
		super();
		this.borrow_id = borrow_id;
		this.reader_name = reader_name;
		this.sex = sex;
		this.college = college;
		this.type = type;
		this.certificate_type = certificate_type;
		this.certificate_id = certificate_id;
		this.phone = phone;
		this.certificate_date = certificate_date;
		this.max_book_num = max_book_num;
	}
	
	public ReaderBean(int borrow_id, String reader_name, String sex, String college, String type,
			String certificate_type, String certificate_id, String phone, String certificate_date, int borrow_book_num,
			int max_book_num, String yuqi_state) {
		super();
		this.borrow_id = borrow_id;
		this.reader_name = reader_name;
		this.sex = sex;
		this.college = college;
		this.type = type;
		this.certificate_type = certificate_type;
		this.certificate_id = certificate_id;
		this.phone = phone;
		this.certificate_date = certificate_date;
		this.borrow_book_num = borrow_book_num;
		this.max_book_num = max_book_num;
		this.yuqi_state = yuqi_state;
	}
	
	
	
	
}
