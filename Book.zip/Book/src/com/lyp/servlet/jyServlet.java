package com.lyp.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lyp.Dao.JieyueDao;
import com.lyp.Dao.ReaderDao;
import com.lyp.Util.DbUtil;
import com.lyp.bean.ReaderBean;
import com.lyp.bean.jieyueBean;

public class jyServlet extends HttpServlet{
	
	DbUtil db = new DbUtil();
	JieyueDao jydao = new JieyueDao();
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
	
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action = request.getParameter("action");
		if(action.equals("queryAll")){
			queryAll(request,response);
		}
	}


	private void queryAll(HttpServletRequest request, HttpServletResponse response) {
		Connection con = null;
		try {
			con = db.getCon();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		List<jieyueBean> list = new ArrayList<jieyueBean>();
		try {
			list = jydao.queryAll(con);
			//System.out.println(list.size());
			//System.out.println(12345);
			request.setAttribute("jieyue", list);
            request.getRequestDispatcher("jyhistory.jsp").forward(request, response); //ת�������߽���
		} catch (Exception e) {
			e.printStackTrace();
		} 
	}
}
