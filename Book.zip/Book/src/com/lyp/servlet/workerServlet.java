package com.lyp.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lyp.Dao.WorkerDao;
import com.lyp.Util.DbUtil;
import com.lyp.bean.WorkerBean;

public class workerServlet extends HttpServlet{
	
	DbUtil dbutil = new DbUtil();
	WorkerDao workerdao = new WorkerDao();
	
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		String action = request.getParameter("who");
		if(action.equals("insert")){
			insert(request,response);
		}else if(action.equals("delete")){
			delete(request,response);
		}else if(action.equals("update")){
			try {
				update(request,response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else if(action.equals("queryAll")){
			queryAll(request,response);
		}
	}
	
	

	private void delete(HttpServletRequest request, HttpServletResponse response) throws IOException {
		int id = Integer.valueOf(request.getParameter("id"));
		PrintWriter out = response.getWriter();
		Connection con = null;
		try {
			
			con = dbutil.getCon();
			int result = workerdao.delete(con, id);
			if(result > 0){
				System.out.print("ɾ���ɹ�!");
	  			out.println("<html><body>");
	  			out.print("<font size=6 color=red >ɾ���ɹ�</font>");
	  			out.println("</body></html>");
			}
			else{
				System.out.print("ɾ��ʧ��!");
	  			out.println("<html><body>");
	  			out.print("<font size=6 color=red >ɾ��ʧ��</font>");
	  			out.println("</body></html>");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void queryAll(HttpServletRequest request, HttpServletResponse response) {
		Connection con = null;
		try {
			con = dbutil.getCon();
		} catch (Exception e) {
			e.printStackTrace();
		}
		WorkerDao workerdao = new WorkerDao();
		List<WorkerBean> list = new ArrayList<WorkerBean>();
		try {
			list = workerdao.query(con);
			request.setAttribute("list", list);
	        request.getRequestDispatcher("zgda.jsp").forward(request, response); //ת����ְ������
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	/*
	private void queryAll(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		
		try {
			con = dbutil.getCon();
			WorkerDao workerdao = new WorkerDao();
			List<WorkerBean> list = new ArrayList<WorkerBean>();
			list = workerdao.query(con);
			request.setAttribute("list", list);
	        request.getRequestDispatcher("zgda.jsp").forward(request, response); //ת����ְ������
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try
		      {
		        this.dbutil.closeCon(con);
		      }
		      catch (Exception e) {
		        e.printStackTrace();
		      }
		}
		
	}*/
    
	//����
	public void insert(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException{
		
		
		
		int id = Integer.parseInt(request.getParameter("id"));
  		String name = request.getParameter("name");
  		int sex = Integer.parseInt(request.getParameter("sex"));
  		String phone = request.getParameter("phone");
  		String password = request.getParameter("password");
  		WorkerBean worker = new WorkerBean(id,name,sex,phone,password);
  		
  		
  		WorkerDao workerdao = new WorkerDao();
  		DbUtil db = new DbUtil();
  		Connection con;
		try {
			con = db.getCon();
			ResultSet rs= workerdao.queryById(con, id);
			PrintWriter out = response.getWriter();
	  		int result = 0;
	  		if(rs.next()){
	  			System.out.println("�Ѵ��ڴ�ְ����Ϣ!!!");
	  			out.println("<html><body>");
		  		out.print("<font size=6 color=blue >�Ѵ��ڴ�ְ����Ϣ</font>");
		  		out.println("</body></html>");
	  			
	  		}else{
	  			result = workerdao.insert(con ,worker);
	  	  		if(result>0){
	  	  			//out.print("���ӳɹ�!");
	  	  			System.out.print("���ӳɹ�!");
	  	  			out.println("<html><body>");
	  	  			out.print("<font size=6 color=red >���ӳɹ�</font>");
	  	  			out.println("</body></html>");
	  	  		}else{
	  	  			System.out.print("����ʧ��!");
	  	  			//out.print("����ʧ��");
	  	  			out.println("<html><body>");
	  	  			out.print("<font size=6 color=yellow >����ʧ��</font>");
	  	  			out.println("</body></html>");
	  	  		}
	  		}
		}catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
  	
  		
 }
  		
	
	
	
	
	//�޸�
	private void update(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException,Exception {
		int id = Integer.valueOf(request.getParameter("id"));
		WorkerDao workerdao = new WorkerDao();
		
		String pwd = request.getParameter("pwd");
		Connection con = null;
		
		con = dbutil.getCon();
		int result = workerdao.update(con,id,pwd);
		PrintWriter out = response.getWriter();
		if(result>0){
			out.println("<html><body>");
  			out.print("<font size=6 color=blue >�޸ĳɹ�</font>");
  			out.println("</body></html>");
		}else{
			System.out.println("ʧ��");
			out.println("<html><body>");
  			out.print("<font size=6 color=blue >�޸�ʧ��</font>");
  			out.println("</body></html>");
		}
	}
	
	
	
}
