package com.lyp.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lyp.Dao.ReaderDao;
import com.lyp.Util.DbUtil;
import com.lyp.bean.ReaderBean;




public class reader extends HttpServlet {
	private static final long serialVersionUID = 1L;
    int num = 0;
    DbUtil db = new DbUtil();

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		String type=request.getParameter("who");
		//����
		if("Insert".equals(type)){
		    Insert(request, response);
		}else if("update".equals(type)){
			 update(request, response);
		}else if("queryById".equals(type)){
			 queryById(request, response);
		}else if("delete".equals(type)){
			delete(request, response);
		}else if("queryAll".equals(type)){
			queryAll(request, response);
		} 
	}
	public void Insert(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
		//��Ҫ�Լ��趨����֤��
		
		response.setContentType("text/html;charset=utf-8");
		response.setCharacterEncoding("utf-8");
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");//�������ڸ�ʽ
		String date = df.format(new Date());// new Date()Ϊ��ȡ��ǰϵͳʱ�䣬Ҳ��ʹ�õ�ǰʱ���
		String reader_name = request.getParameter("name");
		String sex = request.getParameter("sex");
		String college = request.getParameter("college");
		String readertype = request.getParameter("readertype");
		String certificate_type = request.getParameter("certificate_type");
		String certificate_id = request.getParameter("certificate_id");
		String phone = request.getParameter("phone");
		String certificate_date = date;  //��֤����
		int max_book_num;
		if(readertype.equals("ѧ��")){
			max_book_num= 100;
		}else{
			max_book_num = 1000;
		}
		num++;
		int borrow_id=0+num;     //����ʱΪĬ������Ϊ100��
		System.out.println(borrow_id);
		int borrow_book_num = 0;
		String yuqi_state = "δ����";
		ReaderBean reader = new ReaderBean(borrow_id , reader_name , sex , college , readertype , certificate_type , certificate_id , phone , date , borrow_book_num, max_book_num, yuqi_state);
		ReaderDao readerdao = new ReaderDao();
		Connection con;
		int result=0;
		PrintWriter out = response.getWriter();
		
		try {
			con = db.getCon();
			result = readerdao.insert(con, reader);
			if(result>0){
				System.out.print("���ӳɹ�!");
	  			out.println("<html><body>");
	  			out.print("<font size=6 color=red >���ӳɹ�</font>");
	  			out.println("</body></html>");
	  			
			}else{
				System.out.print("����ʧ��!");
	  			out.println("<html><body>");
	  			out.print("<font size=6 color=red >����ʧ��</font>");
	  			out.println("</body></html>");
			}
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		
	}
	//�鿴���ж�����Ϣ
	private void queryAll(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		Connection con = null;
		try {
			con = db.getCon();
		} catch (Exception e) {
			e.printStackTrace();
		}
		//System.out.println(1234);
		ReaderDao readerdao = new ReaderDao();
		List<ReaderBean> list = new ArrayList<ReaderBean>();
		try {
			list = readerdao.query(con);
			//System.out.println(list.size());
			//System.out.println(12345);
			request.setAttribute("list", list);
            request.getRequestDispatcher("reader.jsp").forward(request, response); //ת�������߽���
		} catch (Exception e) {
			e.printStackTrace();
		} 
        
	}


	private void delete(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
		response.setContentType("text/html;charset=utf-8");
		response.setCharacterEncoding("utf-8");
		int id = Integer.valueOf(request.getParameter("id"));
		boolean result = false;
		try {
			Connection con = db.getCon();
			ReaderDao readerdao = new ReaderDao();
			result = readerdao.delete(con, id);
			PrintWriter out = response.getWriter();
			if(result==true){
				System.out.print("ɾ���ɹ�!");
	  			out.println("<html><body>");
	  			out.print("<font size=6 color=red >ɾ���ɹ�</font>");
	  			out.println("</body></html>");
			}else{
				System.out.print("ɾ��ʧ��!");
	  			out.println("<html><body>");
	  			out.print("<font size=6 color=red >ɾ��ʧ��</font>");
	  			out.println("</body></html>");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	//reader��ѯservlet
	private void queryById(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
		
	}

	//reader�޸�servlet
	private void update(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
		
	}
	
}


