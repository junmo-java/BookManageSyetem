package com.lyp.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lyp.Dao.BookDao;
import com.lyp.Dao.BookTypeDao;
import com.lyp.Dao.JieyueDao;
import com.lyp.Dao.ReaderDao;
import com.lyp.Util.DbUtil;
import com.lyp.Util.getDatePoor;
import com.lyp.bean.BookBean;
import com.lyp.bean.jieyueBean;

public class bookServlet extends HttpServlet{
	
	
	DbUtil dbutil = new DbUtil(); 
	Connection con = null;
	BookDao bookdao = new BookDao();
	BookTypeDao booktypedao = new BookTypeDao();
	ReaderDao readerdao = new ReaderDao();
	JieyueDao jieyuedao = new JieyueDao();
	getDatePoor getdate = new getDatePoor();
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action = request.getParameter("action");
		if(action .equals("insert")){
			insert(request,response);
		}else if(action .equals("queryAll")){
			queryAll(request,response);
		}else if(action.equals("delete")){
			delete(request, response);
		}else if(action.equals("guihuan")){
			try {
				guihuan(request , response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else if(action.equals("jiechu")){
			jiechu(request , response);
		}
	}
	
	//ɾ��
	private void delete(HttpServletRequest request, HttpServletResponse response) throws ServletException , IOException {
		PrintWriter out = response.getWriter();
		System.out.println("11--11111!!");
		System.out.println(request.getParameter("id"));
		int bookid = Integer.parseInt(request.getParameter("id"));
		System.out.println(bookid);
		try {
			 con = dbutil.getCon();
			 
			 if( bookdao.delete(con , bookid)){
				 System.out.println("ɾ���ɹ�!!");
				 out.print("<script>alert('ɾ���ɹ�!!')</script>");
			 }else{
				 out.print("<script>alert('ɾ��ʧ��!!')</script>");
			 }
			
			 //request.getRequestDispatcher("listbook.jsp").forward(request, response);
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try{
				dbutil.closeCon(con);
			}catch (Exception e){
				e.printStackTrace();
			}
			
		}
	}
	//�޸�
	private void modify(HttpServletRequest request, HttpServletResponse response) {
		
	}
	
	//���
	private void jiechu(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int book_id = Integer.parseInt(request.getParameter("id"));
		int reader_id = Integer.parseInt(request.getParameter("reader_id"));
		//����������book_id��������, ����reader_id���Ҷ�������
		PrintWriter out = response.getWriter();
		try {
			con = dbutil.getCon();
			String book_name = bookdao.queryBookNameById(con, book_id);
			String reader_name = readerdao.queryReaderNameById(con, reader_id);
			SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
			String borrow_date = df.format(new Date());
			SimpleDateFormat simpleDateFormat=new SimpleDateFormat("yyyy-MM-dd");
			Date jiechu_date=simpleDateFormat.parse(borrow_date);
			//����һ��30�������
			Date yinghuandate = getdate.addDate(jiechu_date);
			String yinghuan_date = simpleDateFormat.format(yinghuandate);
			System.out.println("Ӧ������----"+yinghuan_date);
			jieyueBean jieyuebean = new jieyueBean(book_id, reader_id, reader_name,book_name , borrow_date, yinghuan_date, null);
			int count = jieyuedao.insert(con, jieyuebean);
			if(count > 0){
				//����ɹ������ǲ�����Ҫ -1
				if(bookdao.cangshunumpoor(con, book_id)){
					//����������Ҫ��һ��������
					if(readerdao.addcangshu(con, reader_id)){
						out.print("<script>alert('����ɹ�!!')</script>");
					}
					
				}else{
					out.print("<script>alert('����ʧ��!!')</script>");
				}

			}else{
				out.print("<script>alert('����ʧ��!!')</script>");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try{
				dbutil.closeCon(con);
			}catch (Exception e){
				e.printStackTrace();
			}
		}
	}
	
	//�黹
	private void guihuan(HttpServletRequest request, HttpServletResponse response) throws ServletException,Exception {
		PrintWriter out = response.getWriter();
		int book_id = Integer.parseInt(request.getParameter("id"));
		int reader_id = Integer.parseInt(request.getParameter("reader_id"));
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");//�������ڸ�ʽ
		String returndate = df.format(new Date());
		try {
			con = dbutil.getCon();
			String yinghuandate = jieyuedao.queryDateByBookId(con, book_id,reader_id);
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			Date return_date = sdf.parse(returndate);
			Date yinghuan_date = sdf.parse(yinghuandate);
			long result = getdate.getDate(return_date, yinghuan_date);
			jieyuedao.update(con, returndate, book_id, reader_id);
			if(result > 30){
				//����30��δ��,����������Ϊ�����ڶ���
				if(readerdao.updateyuqi(con, reader_id)){
					System.out.println("ע��˶��������ڶ��ߣ���");
					bookdao.cangshunumadd(con, book_id);
					System.out.println("����ɹ�!!!");
					out.print("<script>alert('����ɹ�')</script>");
				}
			}else {
				bookdao.cangshunumadd(con, book_id);
				System.out.println("����ɹ�!!!");
				out.print("<script>alert('����ɹ�')</script>");
			}
			readerdao.poorcangshu(con, reader_id);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally{
			try{
				dbutil.closeCon(con);
			}catch (Exception e){
				e.printStackTrace();
			}
			
		}
	}
	private void queryAll(HttpServletRequest request, HttpServletResponse response) {
		try {
			 con = dbutil.getCon();
			 List<BookBean> list = new ArrayList<BookBean>();
			 list = bookdao.query(con);
			 request.setAttribute("book", list);
			 request.getRequestDispatcher("listbook.jsp").forward(request, response);
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try{
				dbutil.closeCon(con);
			}catch (Exception e){
				e.printStackTrace();
			}
			
		}
	}
	//����ͼ��
	private void insert(HttpServletRequest request, HttpServletResponse response) throws IOException {
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		int book_id = Integer.parseInt(request.getParameter("book_id"));
		String book_name = request.getParameter("book_name");
		String book_type = request.getParameter("book_type");
		
		String editor = request.getParameter("editor");
		String publishing_house = request.getParameter("publishing_house");
		String price = request.getParameter("price");
		int shujia_id = Integer.parseInt(request.getParameter("shujia_id"))  ;
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd ");//�������ڸ�ʽ
		String date = df.format(new Date());// new Date()Ϊ��ȡ��ǰϵͳʱ�䣬Ҳ��ʹ�õ�ǰʱ���
		String ruku_date = date;
		int num = 0;
		int result = 0;
		PrintWriter out = response.getWriter();
		try {
			 con = dbutil.getCon();
			if(bookdao.queryById(con, book_id)){ //�鵽���Ѿ������Ȿ��
				if(bookdao.updatebooknum(con, book_id)){
					System.out.println("2�Ͳ���!!");
					 out.print("<script>alert('�Ȿ���Ѵ��ڣ�����������1')</script>");
					 request.getRequestDispatcher("addbook.jsp").forward(request, response); //ת�������߽���
				}
			}else{
				int booktype = booktypedao.queryIdByType(con, book_type);
			 num = bookdao.queryBooknum(con, book_id) +1;
			 BookBean bookbean = new BookBean(book_id, book_name, booktype , editor , publishing_house, price ,num, shujia_id , ruku_date);
			 result = bookdao.insert(con, bookbean);
			 if(result > 0){
				 System.out.println("����ɹ�!!!");
				 out.print("<script>alert('���ӳɹ�')</script>");
				 request.getRequestDispatcher("addbook.jsp").forward(request, response); //ת�������߽���
			 }
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try{
				dbutil.closeCon(con);
			}catch (Exception e){
				e.printStackTrace();
			}
			
		}
		
	}
	
}
