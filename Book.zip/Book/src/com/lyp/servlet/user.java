package com.lyp.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lyp.Dao.UserDao;
import com.lyp.Util.DbUtil;

public class user extends HttpServlet{
	DbUtil dbutil = new DbUtil();
	UserDao userdao = new UserDao();
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		String type=request.getParameter("action");
		//����
		if("login".equals(type)){
		    login(request, response);
		}
		
		
		
	}
	private void login(HttpServletRequest request, HttpServletResponse response) {
		String username = request.getParameter("userName");
		String password = request.getParameter("password");
		Connection con = null;
		System.out.println(username+"---"+password);
		if(username == null || password == null){
			System.out.println("�û������������!!");
		}
		else{
			try {
				con = dbutil.getCon();
				boolean result = userdao.select(con , username , password);
				if(result){
					//session.setAttribute("adminname",username);
					request.getRequestDispatcher("index.jsp").forward(request, response);
				}else{
					PrintWriter out = response.getWriter();
					out.print("<script>alert('��¼ʧ��,�˺Ż��������')</script>");
					System.out.println("/////��¼ʧ��/////");
				}
			} catch (Exception e) {
				e.printStackTrace();
			}finally{
				try{
					this.dbutil.closeCon(con);
				}catch (Exception e){
					e.printStackTrace();
				}
			}
		}
	}
}
