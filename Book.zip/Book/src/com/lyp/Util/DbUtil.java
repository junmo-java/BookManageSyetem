package com.lyp.Util;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.lyp.bean.WorkerBean;

public class DbUtil
{
	
  private static  String dbUrl = "jdbc:mysql://localhost:3306/Book_Manage?useUnicode=true&characterEncoding=UTF8";
  private static  String dbUserName = "root";
  private static  String dbPassword = "";
  private static  String jdbcName = "com.mysql.jdbc.Driver";
//  ������Ϊһ��DbUtil������  con
  public Connection getCon()
    throws Exception
  {
    Class.forName(this.jdbcName);
    Connection con = DriverManager.getConnection(this.dbUrl, this.dbUserName, this.dbPassword);
    return con;
  }

  public void closeCon(Connection con) throws Exception {
    if (con != null)
      con.close();
  }
  
}

  	
